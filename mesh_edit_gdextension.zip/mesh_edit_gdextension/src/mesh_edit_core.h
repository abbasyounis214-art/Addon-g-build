#ifndef MESH_EDIT_CORE_H
#define MESH_EDIT_CORE_H

#include "mesh_data.h"
#include <godot_cpp/classes/ref_counted.hpp>
#include <godot_cpp/classes/array_mesh.hpp>
#include <godot_cpp/variant/packed_int32_array.hpp>

using namespace godot;

// Godot-exposed class. All heavy work stays in C++.
class MeshEditCore : public RefCounted {
	GDCLASS(MeshEditCore, RefCounted);

private:
	MeshData data;
	MeshData::Snapshot undo_snapshot;

protected:
	static void _bind_methods();

public:
	MeshEditCore();
	~MeshEditCore();

	// Creation
	void create_cube(float size = 1.0f);
	void create_plane(float size = 1.0f, int subdivisions = 1);

	// Selection helpers (simple for now)
	void clear_selection();
	void select_vertex(int index);
	void select_face(int index);
	PackedInt32Array get_selected_vertices() const;
	PackedInt32Array get_selected_faces() const;

	// Editing
	void translate_selected_vertices(const Vector3 &delta);
	void extrude_selected_faces(float distance);

	// Baking
	Ref<ArrayMesh> bake_mesh() const;

	// Undo
	void take_undo_snapshot();
	void restore_undo_snapshot();

	// Info
	int get_vertex_count() const;
	int get_face_count() const;
	int get_edge_count() const;
};

#endif // MESH_EDIT_CORE_H
