#ifndef MESH_EDIT_REGISTER_TYPES_H
#define MESH_EDIT_REGISTER_TYPES_H

#include <godot_cpp/core/class_db.hpp>

using namespace godot;

void initialize_mesh_edit_module(ModuleInitializationLevel p_level);
void uninitialize_mesh_edit_module(ModuleInitializationLevel p_level);

#endif // MESH_EDIT_REGISTER_TYPES_H
