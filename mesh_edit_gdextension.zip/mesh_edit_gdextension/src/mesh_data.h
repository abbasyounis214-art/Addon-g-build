#ifndef MESH_DATA_H
#define MESH_DATA_H

#include <godot_cpp/variant/vector3.hpp>
#include <godot_cpp/variant/vector2.hpp>
#include <godot_cpp/variant/packed_vector3_array.hpp>
#include <godot_cpp/variant/packed_vector2_array.hpp>
#include <godot_cpp/variant/packed_int32_array.hpp>
#include <godot_cpp/variant/packed_float32_array.hpp>
#include <godot_cpp/classes/array_mesh.hpp>
#include <godot_cpp/templates/vector.hpp>
#include <godot_cpp/templates/hash_map.hpp>

using namespace godot;

// Compact, cache-friendly mesh representation optimized for editing.
// Designed for blockout / level geometry (hundreds to low tens of thousands of faces).

struct MeshFace {
	Vector<int32_t> vertex_indices; // winding order (usually 3 or 4)
	Vector3 normal;
	int32_t material_id = 0;
};

struct MeshEdge {
	int32_t v0 = -1;
	int32_t v1 = -1;
	// Optional: face adjacency can be added later if needed
};

class MeshData {
public:
	Vector<Vector3> vertices;
	Vector<Vector2> uvs;
	Vector<Vector3> normals; // per-vertex or per-face depending on mode
	Vector<MeshFace> faces;
	Vector<MeshEdge> edges;

	// Selection (indices into the arrays above)
	Vector<int32_t> selected_vertices;
	Vector<int32_t> selected_edges;
	Vector<int32_t> selected_faces;

	// --- Construction ---
	void clear();
	void create_cube(float size = 1.0f);
	void create_plane(float size = 1.0f, int subdivisions = 1);

	// --- Queries ---
	int get_vertex_count() const { return vertices.size(); }
	int get_face_count() const { return faces.size(); }
	int get_edge_count() const { return edges.size(); }

	Vector3 get_centroid(const Vector<int32_t> &indices) const;

	// --- Editing ---
	void translate_vertices(const Vector<int32_t> &indices, const Vector3 &delta);
	void extrude_faces(const Vector<int32_t> &face_indices, float distance);

	// Rebuild edge list from faces (call after topology changes)
	void rebuild_edges();

	// --- Baking ---
	Ref<ArrayMesh> bake() const;

	// --- Undo support ---
	struct Snapshot {
		Vector<Vector3> vertices;
		Vector<Vector2> uvs;
		Vector<MeshFace> faces;
		Vector<MeshEdge> edges;
	};

	Snapshot take_snapshot() const;
	void restore_snapshot(const Snapshot &snap);

private:
	void compute_face_normals();
};
#endif // MESH_DATA_H
