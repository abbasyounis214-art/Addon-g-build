#include "mesh_edit_core.h"
#include <godot_cpp/core/class_db.hpp>

using namespace godot;

void MeshEditCore::_bind_methods() {
	ClassDB::bind_method(D_METHOD("create_cube", "size"), &MeshEditCore::create_cube, DEFVAL(1.0f));
	ClassDB::bind_method(D_METHOD("create_plane", "size", "subdivisions"), &MeshEditCore::create_plane, DEFVAL(1.0f), DEFVAL(1));

	ClassDB::bind_method(D_METHOD("clear_selection"), &MeshEditCore::clear_selection);
	ClassDB::bind_method(D_METHOD("select_vertex", "index"), &MeshEditCore::select_vertex);
	ClassDB::bind_method(D_METHOD("select_face", "index"), &MeshEditCore::select_face);
	ClassDB::bind_method(D_METHOD("get_selected_vertices"), &MeshEditCore::get_selected_vertices);
	ClassDB::bind_method(D_METHOD("get_selected_faces"), &MeshEditCore::get_selected_faces);

	ClassDB::bind_method(D_METHOD("translate_selected_vertices", "delta"), &MeshEditCore::translate_selected_vertices);
	ClassDB::bind_method(D_METHOD("extrude_selected_faces", "distance"), &MeshEditCore::extrude_selected_faces);

	ClassDB::bind_method(D_METHOD("bake_mesh"), &MeshEditCore::bake_mesh);

	ClassDB::bind_method(D_METHOD("take_undo_snapshot"), &MeshEditCore::take_undo_snapshot);
	ClassDB::bind_method(D_METHOD("restore_undo_snapshot"), &MeshEditCore::restore_undo_snapshot);

	ClassDB::bind_method(D_METHOD("get_vertex_count"), &MeshEditCore::get_vertex_count);
	ClassDB::bind_method(D_METHOD("get_face_count"), &MeshEditCore::get_face_count);
	ClassDB::bind_method(D_METHOD("get_edge_count"), &MeshEditCore::get_edge_count);
}

MeshEditCore::MeshEditCore() {}
MeshEditCore::~MeshEditCore() {}

void MeshEditCore::create_cube(float size) {
	data.create_cube(size);
}

void MeshEditCore::create_plane(float size, int subdivisions) {
	data.create_plane(size, subdivisions);
}

void MeshEditCore::clear_selection() {
	data.selected_vertices.clear();
	data.selected_edges.clear();
	data.selected_faces.clear();
}

void MeshEditCore::select_vertex(int index) {
	if (index >= 0 && index < data.vertices.size()) {
		data.selected_vertices.push_back(index);
	}
}

void MeshEditCore::select_face(int index) {
	if (index >= 0 && index < data.faces.size()) {
		data.selected_faces.push_back(index);
	}
}

PackedInt32Array MeshEditCore::get_selected_vertices() const {
	PackedInt32Array arr;
	for (int i = 0; i < data.selected_vertices.size(); i++) {
		arr.push_back(data.selected_vertices[i]);
	}
	return arr;
}

PackedInt32Array MeshEditCore::get_selected_faces() const {
	PackedInt32Array arr;
	for (int i = 0; i < data.selected_faces.size(); i++) {
		arr.push_back(data.selected_faces[i]);
	}
	return arr;
}

void MeshEditCore::translate_selected_vertices(const Vector3 &delta) {
	data.translate_vertices(data.selected_vertices, delta);
}

void MeshEditCore::extrude_selected_faces(float distance) {
	data.extrude_faces(data.selected_faces, distance);
}

Ref<ArrayMesh> MeshEditCore::bake_mesh() const {
	return data.bake();
}

void MeshEditCore::take_undo_snapshot() {
	undo_snapshot = data.take_snapshot();
}

void MeshEditCore::restore_undo_snapshot() {
	data.restore_snapshot(undo_snapshot);
}

int MeshEditCore::get_vertex_count() const {
	return data.get_vertex_count();
}

int MeshEditCore::get_face_count() const {
	return data.get_face_count();
}

int MeshEditCore::get_edge_count() const {
	return data.get_edge_count();
}
