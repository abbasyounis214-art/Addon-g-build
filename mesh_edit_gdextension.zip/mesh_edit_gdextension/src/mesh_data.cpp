#include "mesh_data.h"
#include <godot_cpp/core/class_db.hpp>
#include <godot_cpp/variant/utility_functions.hpp>

using namespace godot;

void MeshData::clear() {
	vertices.clear();
	uvs.clear();
	normals.clear();
	faces.clear();
	edges.clear();
	selected_vertices.clear();
	selected_edges.clear();
	selected_faces.clear();
}

void MeshData::create_cube(float size) {
	clear();
	const float h = size * 0.5f;

	// 8 vertices
	vertices.push_back(Vector3(-h, -h, -h)); // 0
	vertices.push_back(Vector3( h, -h, -h)); // 1
	vertices.push_back(Vector3( h,  h, -h)); // 2
	vertices.push_back(Vector3(-h,  h, -h)); // 3
	vertices.push_back(Vector3(-h, -h,  h)); // 4
	vertices.push_back(Vector3( h, -h,  h)); // 5
	vertices.push_back(Vector3( h,  h,  h)); // 6
	vertices.push_back(Vector3(-h,  h,  h)); // 7

	// Simple UVs (one set per vertex for now)
	for (int i = 0; i < 8; i++) {
		uvs.push_back(Vector2(0, 0));
	}

	// 6 faces (quads)
	auto add_face = [&](int a, int b, int c, int d) {
		MeshFace f;
		f.vertex_indices.push_back(a);
		f.vertex_indices.push_back(b);
		f.vertex_indices.push_back(c);
		f.vertex_indices.push_back(d);
		faces.push_back(f);
	};

	add_face(0, 1, 2, 3); // back
	add_face(5, 4, 7, 6); // front
	add_face(4, 0, 3, 7); // left
	add_face(1, 5, 6, 2); // right
	add_face(3, 2, 6, 7); // top
	add_face(4, 5, 1, 0); // bottom

	compute_face_normals();
	rebuild_edges();
}

void MeshData::create_plane(float size, int subdivisions) {
	clear();
	const float h = size * 0.5f;
	const int res = subdivisions + 1;

	for (int z = 0; z < res; z++) {
		for (int x = 0; x < res; x++) {
			float u = float(x) / float(subdivisions);
			float v = float(z) / float(subdivisions);
			vertices.push_back(Vector3(
				Math::lerp(-h, h, u),
				0.0f,
				Math::lerp(-h, h, v)
			));
			uvs.push_back(Vector2(u, v));
		}
	}

	for (int z = 0; z < subdivisions; z++) {
		for (int x = 0; x < subdivisions; x++) {
			int i = z * res + x;
			MeshFace f;
			f.vertex_indices.push_back(i);
			f.vertex_indices.push_back(i + 1);
			f.vertex_indices.push_back(i + 1 + res);
			f.vertex_indices.push_back(i + res);
			faces.push_back(f);
		}
	}

	compute_face_normals();
	rebuild_edges();
}

Vector3 MeshData::get_centroid(const Vector<int32_t> &indices) const {
	if (indices.is_empty()) {
		return Vector3();
	}
	Vector3 sum;
	for (int i = 0; i < indices.size(); i++) {
		int idx = indices[i];
		if (idx >= 0 && idx < vertices.size()) {
			sum += vertices[idx];
		}
	}
	return sum / float(indices.size());
}

void MeshData::translate_vertices(const Vector<int32_t> &indices, const Vector3 &delta) {
	for (int i = 0; i < indices.size(); i++) {
		int idx = indices[i];
		if (idx >= 0 && idx < vertices.size()) {
			vertices.write[idx] += delta;
		}
	}
	compute_face_normals();
}

void MeshData::extrude_faces(const Vector<int32_t> &face_indices, float distance) {
	if (face_indices.is_empty() || Math::is_zero_approx(distance)) {
		return;
	}

	// Simple extrusion: duplicate the face vertices, move them along normal, create side faces.
	// This is a basic implementation suitable for blockout.

	HashMap<int32_t, int32_t> old_to_new;

	for (int fi = 0; fi < face_indices.size(); fi++) {
		int fidx = face_indices[fi];
		if (fidx < 0 || fidx >= faces.size()) {
			continue;
		}

		MeshFace &face = faces.write[fidx];
		Vector3 n = face.normal;

		// Create new vertices
		Vector<int32_t> new_indices;
		for (int vi = 0; vi < face.vertex_indices.size(); vi++) {
			int old_idx = face.vertex_indices[vi];
			if (!old_to_new.has(old_idx)) {
				Vector3 new_pos = vertices[old_idx] + n * distance;
				int new_idx = vertices.size();
				vertices.push_back(new_pos);
				if (old_idx < uvs.size()) {
					uvs.push_back(uvs[old_idx]);
				} else {
					uvs.push_back(Vector2());
				}
				old_to_new[old_idx] = new_idx;
			}
			new_indices.push_back(old_to_new[old_idx]);
		}

		// Side faces (quads)
		int count = face.vertex_indices.size();
		for (int i = 0; i < count; i++) {
			int next = (i + 1) % count;
			int a = face.vertex_indices[i];
			int b = face.vertex_indices[next];
			int c = new_indices[next];
			int d = new_indices[i];

			MeshFace side;
			side.vertex_indices.push_back(a);
			side.vertex_indices.push_back(b);
			side.vertex_indices.push_back(c);
			side.vertex_indices.push_back(d);
			faces.push_back(side);
		}

		// Replace original face with the extruded one
		face.vertex_indices = new_indices;
	}

	compute_face_normals();
	rebuild_edges();
}

void MeshData::rebuild_edges() {
	edges.clear();
	HashMap<int64_t, bool> seen;

	auto edge_key = [](int a, int b) -> int64_t {
		if (a > b) {
			int t = a;
			a = b;
			b = t;
		}
		return (int64_t(a) << 32) | int64_t(b);
	};

	for (int fi = 0; fi < faces.size(); fi++) {
		const MeshFace &f = faces[fi];
		int count = f.vertex_indices.size();
		for (int i = 0; i < count; i++) {
			int a = f.vertex_indices[i];
			int b = f.vertex_indices[(i + 1) % count];
			int64_t key = edge_key(a, b);
			if (!seen.has(key)) {
				seen[key] = true;
				MeshEdge e;
				e.v0 = a;
				e.v1 = b;
				edges.push_back(e);
			}
		}
	}
}

void MeshData::compute_face_normals() {
	for (int i = 0; i < faces.size(); i++) {
		MeshFace &f = faces.write[i];
		if (f.vertex_indices.size() < 3) {
			f.normal = Vector3(0, 1, 0);
			continue;
		}
		Vector3 a = vertices[f.vertex_indices[0]];
		Vector3 b = vertices[f.vertex_indices[1]];
		Vector3 c = vertices[f.vertex_indices[2]];
		f.normal = (b - a).cross(c - a).normalized();
	}
}

Ref<ArrayMesh> MeshData::bake() const {
	Ref<ArrayMesh> mesh;
	mesh.instantiate();

	PackedVector3Array verts;
	PackedVector3Array norms;
	PackedVector2Array uv0;
	PackedInt32Array indices;

	// Fan triangulation of each face
	for (int fi = 0; fi < faces.size(); fi++) {
		const MeshFace &f = faces[fi];
		if (f.vertex_indices.size() < 3) {
			continue;
		}

		int base = verts.size();
		Vector3 n = f.normal;

		for (int vi = 0; vi < f.vertex_indices.size(); vi++) {
			int idx = f.vertex_indices[vi];
			verts.push_back(vertices[idx]);
			norms.push_back(n);
			if (idx < uvs.size()) {
				uv0.push_back(uvs[idx]);
			} else {
				uv0.push_back(Vector2());
			}
		}

		// Triangle fan
		for (int i = 1; i < f.vertex_indices.size() - 1; i++) {
			indices.push_back(base);
			indices.push_back(base + i);
			indices.push_back(base + i + 1);
		}
	}

	Array arrays;
	arrays.resize(Mesh::ARRAY_MAX);
	arrays[Mesh::ARRAY_VERTEX] = verts;
	arrays[Mesh::ARRAY_NORMAL] = norms;
	arrays[Mesh::ARRAY_TEX_UV] = uv0;
	arrays[Mesh::ARRAY_INDEX] = indices;

	mesh->add_surface_from_arrays(Mesh::PRIMITIVE_TRIANGLES, arrays);
	return mesh;
}

MeshData::Snapshot MeshData::take_snapshot() const {
	Snapshot s;
	s.vertices = vertices;
	s.uvs = uvs;
	s.faces = faces;
	s.edges = edges;
	return s;
}

void MeshData::restore_snapshot(const Snapshot &snap) {
	vertices = snap.vertices;
	uvs = snap.uvs;
	faces = snap.faces;
	edges = snap.edges;
	selected_vertices.clear();
	selected_edges.clear();
	selected_faces.clear();
}
