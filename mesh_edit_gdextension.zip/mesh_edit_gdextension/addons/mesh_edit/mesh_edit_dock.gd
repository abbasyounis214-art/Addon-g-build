@tool
extends VBoxContainer

var core: MeshEditCore
var current_mesh_instance: MeshInstance3D

func set_core(p_core: MeshEditCore) -> void:
	core = p_core
	$BtnCube.pressed.connect(_on_create_cube)
	$BtnPlane.pressed.connect(_on_create_plane)
	$BtnExtrude.pressed.connect(_on_extrude)

func _on_create_cube() -> void:
	if not core:
		return
	core.create_cube(1.0)
	_update_mesh()
	_update_info()

func _on_create_plane() -> void:
	if not core:
		return
	core.create_plane(2.0, 2)
	_update_mesh()
	_update_info()

func _on_extrude() -> void:
	if not core:
		return
	# For demo: select first face and extrude
	core.clear_selection()
	if core.get_face_count() > 0:
		core.select_face(0)
		core.take_undo_snapshot()
		core.extrude_selected_faces(0.5)
		_update_mesh()
		_update_info()

func _update_mesh() -> void:
	if not core:
		return

	var mesh = core.bake_mesh()
	if not current_mesh_instance:
		current_mesh_instance = MeshInstance3D.new()
		current_mesh_instance.name = "MeshEditResult"
		# Add to the edited scene root if possible
		var editor = EditorInterface.get_edited_scene_root()
		if editor:
			editor.add_child(current_mesh_instance)
			current_mesh_instance.owner = editor
		else:
			# Fallback
			get_tree().edited_scene_root.add_child(current_mesh_instance)

	current_mesh_instance.mesh = mesh

func _update_info() -> void:
	if core:
		$Info.text = "Vertices: %d | Faces: %d | Edges: %d" % [
			core.get_vertex_count(),
			core.get_face_count(),
			core.get_edge_count()
		]
