@tool
extends EditorPlugin

# Thin GDScript shell. All heavy work is done by the C++ MeshEditCore class.

var core: MeshEditCore
var dock: Control

func _enter_tree() -> void:
	# The C++ class becomes available after the .gdextension is loaded
	core = MeshEditCore.new()

	# Simple dock for testing
	dock = preload("res://addons/mesh_edit/mesh_edit_dock.tscn").instantiate()
	dock.set_core(core)
	add_control_to_dock(DOCK_SLOT_LEFT_UL, dock)

func _exit_tree() -> void:
	if dock:
		remove_control_from_docks(dock)
		dock.queue_free()
	core = null
