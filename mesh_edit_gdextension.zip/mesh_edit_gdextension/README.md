# Mesh Edit – High Performance C++ GDExtension for Godot 4.7

Fast mesh editing core written in C++.  
GDScript is only used for the thin editor UI.

## Features (v0.1)

- Create Cube / Plane
- Select faces / vertices
- Translate vertices
- Extrude faces
- Bake to ArrayMesh
- Undo snapshot

## Requirements

- Godot 4.7.1 (or 4.7.x)
- Windows
- Visual Studio 2022 with “Desktop development with C++”
- Python + SCons (`pip install scons`)
- Git

## Build Instructions (Windows – copy & paste)

1. Open **x64 Native Tools Command Prompt for VS 2022**  
   (search for it in the Start menu)

2. Go to a folder where you want the project, then run:

```bat
git clone --recursive https://github.com/godotengine/godot-cpp.git
cd godot-cpp
git checkout 4.3
cd ..
```

(Note: 4.3 branch of godot-cpp is compatible with 4.7 in most cases. If you have problems later we can switch.)

3. Copy the entire `mesh_edit_gdextension` folder next to the `godot-cpp` folder so you have:

```
your_folder/
├── godot-cpp/
└── mesh_edit_gdextension/
    ├── SConstruct
    ├── src/
    └── addons/
```

4. Go into the extension folder and compile:

```bat
cd mesh_edit_gdextension
scons platform=windows target=template_debug
```

First compile takes several minutes.

5. After it finishes you will find the `.dll` in:

`addons/mesh_edit/bin/libmesh_edit.windows.template_debug.x86_64.dll`

6. Copy the whole `addons/mesh_edit` folder into your Godot project’s `addons/` folder.

7. Open Godot → Project → Project Settings → Plugins → Enable **Mesh Edit**.

8. A dock appears on the left. Click “Create Cube” to test.

## Notes

- This is a solid foundation, not a full ProBuilder clone yet.
- All heavy geometry work is in C++.
- We can add inset, bevel, loop cut, better selection, gizmos, etc. on top of this core.

## Troubleshooting

- “Unable to load” → the .dll path in the .gdextension file is wrong or you compiled for the wrong target.
- Always use the same architecture (x86_64).
- Make sure you compiled with `target=template_debug` while developing.
